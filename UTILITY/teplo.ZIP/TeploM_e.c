

//        �ணࠬ�� ���� ����稭 Tau,Kq � 1/Kq � ᮮ⢥��⢨�
// � ��襨��������� ⥮ਥ�.

# include  <stdio.h>
# include  <dos.h>
# include  <stdlib.h>
# include  <process.h>
# include  <math.h>

  typedef unsigned char     byte  ;
  typedef unsigned int      word  ;
  typedef unsigned          u     ;
  typedef unsigned int      w     ;
  typedef   signed int      sw    ;
  typedef unsigned long int lword ;
  typedef unsigned long int lw    ;
  typedef   signed long int slw   ;
  typedef double            d     ;

#define  _MAIN_INCLUDE

#define  _fSec(data) ( (d)data*256 )
#define  _Id_nom( data )  (w)(200.*data)
word Timer1_fSec ;
word Id ;
# include  "teplo_e.h"
# include  "teplo_r.h"
# include  "teplo_e.c"



void main ( void )
{
  word time ;
  Teplo_exp ( 0, &tpl, &ctpl ) ;
  Timer1_fSec = 0 ;
  printf("\r\n");

  Id = _Id_nom(2.0), time = Timer1_fSec ;
  for ( ;; Timer1_fSec+=_fSec(0.004) )
  {
    if ((w)(Timer1_fSec-time)>_fSec(0.02))
    {
      time = Timer1_fSec ;
      if ( Id == _Id_nom(2.0) ) Id = _Id_nom(1.0) ;
      else                      Id = _Id_nom(2.0) ;
    }
    //while ( Teplo_exp ( 1, &tpl, &ctpl ) != 0 );
    printf ("\n %4.2f ", (d)tpl.Ix/_Id_nom(1) ) ;
    if ( Teplo_exp ( 1, &tpl, &ctpl ) == 1 )
    {
      printf (" Time = %5.2f  Id = %4.2f I = %4.2f  Integr = %6.4f  I_max = %4.2f \n",
       (d)Timer1_fSec/256, (d)Id/_Id_nom(1), (d)tpl.Ix/_Id_nom(1),(d)tpl.Integr/_Id_nom(1*65535),(d)tpl.I_max/_Id_nom(1) )  ;
    }
  }
  return ;
}
//�������������������������������

